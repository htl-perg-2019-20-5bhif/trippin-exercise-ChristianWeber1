﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace CSTrppinExercise
{

    public class DataParser
    {
        private readonly HttpClient client;

        public DataParser()
        {

        }

        public Users GetUsers()
        {

            using (StreamReader r = new StreamReader("users.json"))
            {
                string json = r.ReadToEnd();
                Console.WriteLine(json);
                var users = JsonSerializer.Deserialize<Users>(json);
                //return users.Items.Select(p => p.UserName);
                return users;
            }
            
            //return user.Results.Select(p => p.Name);
        }

        public async Task<Users> Get()
        {
            var response = await client.GetAsync("https://services.odata.org/TripPinRESTierService/(S(v10opm5p1k3doaj1ruaflj1h))/People");
            response.EnsureSuccessStatusCode();
            var jsonString = await response.Content.ReadAsStringAsync();
            var users = JsonSerializer.Deserialize<Users>(jsonString);
            //return users.Items.Select(p => p.UserName);
            return users;
        }


        /*public async Task<IEnumerable<string>> Get()
        {
            var response = await client.GetAsync("pokemon");
            response.EnsureSuccessStatusCode();
            var pokemonJsonString = await response.Content.ReadAsStringAsync();
            var pokemon = JsonSerializer.Deserialize<Pokemons>(pokemonJsonString);
            return pokemon.Results.Select(p => p.Name);

        }*/
    }
}
