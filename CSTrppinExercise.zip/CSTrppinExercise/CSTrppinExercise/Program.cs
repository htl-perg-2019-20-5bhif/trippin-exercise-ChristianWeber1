﻿using System;

namespace CSTrppinExercise
{
    class Program
    {
        static async System.Threading.Tasks.Task Main(string[] args)
        {
            DataParser parser = new DataParser();

            //Users users = parser.GetUsers();
            //Console.WriteLine(users.Results[2].UserName);

            Users users = await parser.Get();
            Console.WriteLine(users.Items[2].UserName);

            //Get Users from users.json

            //foreach (user in users) 
            //boolean userExists(username)
            //true 
            //false
            //  postUser POST https://services.odata.org/(S(a13ak2kouvkgru2fhcaluutp))/TripPinRESTierService/People
            //      Key = (S(a13ak2kouvkgru2fhcaluutp))
        }


    }
}
