using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace CSTrppinExercise
{

    //Data Transfer Objects

        /*
    public class Pokemon
    {
        [JsonPropertyName("name")]
        public string Name { get; set; }
    }

    public class Pokemons
    {
        [JsonPropertyName("results")]
        public List<Pokemon> Results { get; set; }
    }
    */
    public class User
    {
        [JsonPropertyName("UserName")]
        public string UserName { get; set; }
        /*  Datenkatalog Entit�tsformulationsformular
        [JsonPropertyName("FirstName")]
        public string FirstName { get; set; }
        
        [JsonPropertyName("LastName")]
        public string LastName { get; set; }

        [JsonPropertyName("Email")]
        public string Email { get; set; }

        [JsonPropertyName("Address")]
        public string Address { get; set; }

        [JsonPropertyName("CityName")]
        public string CityName { get; set; }

        [JsonPropertyName("Country")]
        public string Country { get; set; }*/
    }

    public class Users
    {
        [JsonPropertyName("results")]
        public List<User> Items { get; set; }
    }

    /*{
        "UserName": "pbaglow0",
        "FirstName": "Paola",
        "LastName": "Baglow",
        "Email": "pbaglow0@alexa.com",
        "Address": "6 Lakewood Gardens Park",
        "CityName": "Laixi",
        "Country": "China"
    },*/
}
